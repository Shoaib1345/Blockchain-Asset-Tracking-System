// Migration 1: Deploy the Truffle Migrations helper contract
// This file is required by Truffle — do not delete it

const Migrations = artifacts.require("Migrations");

module.exports = function (deployer) {
  deployer.deploy(Migrations);
};
