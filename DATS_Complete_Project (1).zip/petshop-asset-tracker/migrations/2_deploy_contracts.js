// Migration 2: Deploy our main PetShopAssetTracker contract
// Truffle runs this automatically when you do: truffle migrate

const PetShopAssetTracker = artifacts.require("PetShopAssetTracker");

module.exports = function (deployer) {
  deployer.deploy(PetShopAssetTracker);
};
