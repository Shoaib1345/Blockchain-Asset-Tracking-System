/**
 * truffle-config.js
 * 
 * Truffle reads this file to know:
 *  - which blockchain network to connect to
 *  - which Solidity compiler version to use
 */

module.exports = {

  networks: {
    // "development" = your local Ganache blockchain
    development: {
      host:       "127.0.0.1",  // localhost
      port:       7545,          // Ganache GUI uses 7545 by default
      network_id: "*"            // match any network ID
    }
  },

  compilers: {
    solc: {
      version: "0.8.20",          // Must match pragma in your .sol files
      settings: {
        optimizer: {
          enabled: true,
          runs: 200               // Optimise for ~200 calls over contract lifetime
        }
      }
    }
  }
};
