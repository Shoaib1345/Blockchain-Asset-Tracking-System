// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// =============================================================
//   PetShopAssetTracker — Decentralized Asset Tracking System
//   University Project | Blockchain + Smart Contracts
// =============================================================

contract PetShopAssetTracker {

    // ── 1. DATA MODEL ─────────────────────────────────────────
    // A struct is like a custom "object" in Solidity
    struct Pet {
        uint256 id;       // Unique ID (auto-incremented)
        string  name;     // Asset name e.g. "Buddy"
        string  species;  // Category   e.g. "Dog"
        address owner;    // Who owns this asset (Ethereum address)
    }

    // ── 2. STATE VARIABLES ────────────────────────────────────
    // These are stored permanently on the blockchain

    address public contractOwner;           // The person who deployed the contract
    uint256 public petCount;                // How many pets have been added

    mapping(uint256 => Pet)          public pets;          // ID → Pet record
    mapping(address => uint256[])    private ownerToPetIds; // address → list of owned IDs

    // ── 3. EVENTS ─────────────────────────────────────────────
    // Events are like "notifications" stored on the blockchain forever
    // Anyone can search them as an audit log

    event PetAdded(
        uint256 indexed petId,
        string  name,
        string  species,
        address indexed owner
    );

    event OwnershipTransferred(
        uint256 indexed petId,
        address indexed from,
        address indexed to
    );

    event ContractOwnerChanged(
        address indexed previousOwner,
        address indexed newOwner
    );

    // ── 4. CONSTRUCTOR ────────────────────────────────────────
    // Runs ONCE when the contract is deployed
    constructor() {
        contractOwner = msg.sender; // deployer becomes the admin
    }

    // ── 5. MODIFIERS ──────────────────────────────────────────
    // Modifiers are reusable access-control checks

    // Only the contract admin can call this function
    modifier onlyContractOwner() {
        require(
            msg.sender == contractOwner,
            "DATS: You are not the contract owner"
        );
        _;
    }

    // Only the owner of a specific pet can call this function
    modifier onlyPetOwner(uint256 petId) {
        require(
            pets[petId].owner == msg.sender,
            "DATS: You are not the owner of this pet"
        );
        _;
    }

    // Checks that the petId actually exists
    modifier validPetId(uint256 petId) {
        require(
            petId > 0 && petId <= petCount,
            "DATS: Invalid pet ID — must be between 1 and petCount"
        );
        _;
    }

    // ── 6. WRITE FUNCTIONS ────────────────────────────────────
    // These CHANGE the blockchain state (cost gas)

    /**
     * @notice Register a new pet/asset on the blockchain.
     *         Only the contract owner (admin) can add pets.
     * @param _name    Name of the pet e.g. "Buddy"
     * @param _species Type of pet  e.g. "Dog"
     */
    function addPet(string memory _name, string memory _species)
        external
        onlyContractOwner
    {
        // Validation — make sure fields are not empty
        require(bytes(_name).length    > 0, "DATS: Name cannot be empty");
        require(bytes(_species).length > 0, "DATS: Species cannot be empty");

        // Increment counter FIRST (so IDs start at 1, not 0)
        petCount++;

        // Store the new pet in the mapping
        pets[petCount] = Pet({
            id:      petCount,
            name:    _name,
            species: _species,
            owner:   msg.sender      // contract owner is the first owner
        });

        // Track which IDs this address owns
        ownerToPetIds[msg.sender].push(petCount);

        // Emit event so anyone can see a new pet was added
        emit PetAdded(petCount, _name, _species, msg.sender);
    }

    /**
     * @notice Transfer a pet to a new owner.
     *         Only the current owner of that pet can do this.
     * @param petId    ID of the pet to transfer
     * @param newOwner Ethereum address of the new owner
     */
    function transferPetOwnership(uint256 petId, address newOwner)
        external
        validPetId(petId)
        onlyPetOwner(petId)
    {
        require(newOwner != address(0), "DATS: Cannot transfer to the zero address");
        require(newOwner != msg.sender,  "DATS: You already own this pet");

        address previousOwner = pets[petId].owner;

        // Update the owner in the Pet record
        pets[petId].owner = newOwner;

        // Track the new owner's pet IDs
        ownerToPetIds[newOwner].push(petId);

        // Emit event — permanent audit log entry
        emit OwnershipTransferred(petId, previousOwner, newOwner);
    }

    /**
     * @notice Hand over the contract admin role to someone else.
     *         Only the current contract owner can do this.
     * @param newOwner New admin's Ethereum address
     */
    function changeContractOwner(address newOwner)
        external
        onlyContractOwner
    {
        require(newOwner != address(0), "DATS: Zero address not allowed");
        address previous = contractOwner;
        contractOwner = newOwner;
        emit ContractOwnerChanged(previous, newOwner);
    }

    // ── 7. READ FUNCTIONS (view) ──────────────────────────────
    // These READ from the blockchain — they are FREE (no gas cost)

    /**
     * @notice Get the full record of a pet by its ID.
     * @param petId The pet's unique ID (starts at 1)
     * @return Pet struct with id, name, species, owner
     */
    function getPet(uint256 petId)
        external
        view
        validPetId(petId)
        returns (Pet memory)
    {
        return pets[petId];
    }

    /**
     * @notice Get all pet IDs owned by a specific address.
     * @param _owner The Ethereum address to check
     * @return Array of pet IDs owned by that address
     */
    function getPetsByOwner(address _owner)
        external
        view
        returns (uint256[] memory)
    {
        return ownerToPetIds[_owner];
    }

    /**
     * @notice Get all pets ever registered (full list).
     * @return Array of all Pet structs
     */
    function getAllPets()
        external
        view
        returns (Pet[] memory)
    {
        Pet[] memory allPets = new Pet[](petCount);
        for (uint256 i = 1; i <= petCount; i++) {
            allPets[i - 1] = pets[i];
        }
        return allPets;
    }
}
